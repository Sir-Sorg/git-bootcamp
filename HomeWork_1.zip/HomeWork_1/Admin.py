print('Here is the admin panel of Coca-Cola')
