print('Here is the home page of Coca-Cola')
