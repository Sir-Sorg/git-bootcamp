print('Here is the shop page of Coca-Cola')
